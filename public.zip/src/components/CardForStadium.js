import React from 'react'

function CardForStadium() {
  return (
    <div>CardForStadium</div>
  )
}

export default CardForStadium