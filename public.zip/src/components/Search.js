import React, { useState } from 'react';
import img from '../img/Дизайн без названия (4).png';

function Search({ locations, onSearchResults }) {
  const [query, setQuery] = useState('');
  const [filteredLocations, setFilteredLocations] = useState([]); // State to store filtered locations
  const [visible, setVisible] = useState(false);

  const handleInputChange = (e) => {
    const value = e.target.value.toLowerCase();
    setQuery(value);

    if (value.trim() === '') {
      // If input is empty, clear the filtered locations and hide results
      setFilteredLocations([]);
      onSearchResults([]); // Clear the results in the parent component
      setVisible(false);
      return;
    }

    // Filter locations based on the query matching either the name or the type (hotel or hub)
    const filtered = locations.filter(location => {
      const name = location.name ? location.name.toLowerCase() : ''; // Check if name exists
      const type = location.openType ? location.openType.toLowerCase() : ''; // Check if openType exists

      const matchesName = name.includes(value);
      const matchesType = type.includes(value);
      return matchesName || matchesType;
    });

    console.log("Filtered Locations:", filtered); // Debugging log

    setFilteredLocations(filtered); // Update the state with filtered locations
    onSearchResults(filtered); // Pass filtered locations back to the parent component
    setVisible(filtered.length > 0); // Show results only if there are any
  };

  return (
    <div className="search_div">
      <div className="search">
        <img src={img} alt="Search Icon" />
        <input
          type="search"
          value={query}
          onChange={handleInputChange}
          placeholder="Search locations..."
        />
        <i className="fa-solid fa-magnifying-glass"></i>
      </div>
      {visible && (
        <div className="searched_data">
          {filteredLocations.map((location, index) => (
            <div key={index} className="searched_card">
              <div className="card_left">
                <i className="fa-solid fa-location-dot"></i>
                <h5>{location.name}</h5> {/* Display the location name */}
              </div>
              <button className="card_right">
                <i class="fa-solid fa-route"></i>
                {/* // <p>Get directions</p> */}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Search;
