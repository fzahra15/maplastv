import React from 'react'

function LocationsCard() {
  return (
    <div>LocationsCard</div>
  )
}

export default LocationsCard